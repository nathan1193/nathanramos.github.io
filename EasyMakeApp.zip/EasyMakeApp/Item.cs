﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyMakeApp
{
    class Item
    {
        public string Name;
        private float Amount;
        private string Amounttype;

        public Item(string name, float amount,string amounttype)
        {
            Name = name;
            AAmount = amount;
            AAmounttype = amounttype;
        }
        public float AAmount
        {
            get { return Amount; }
            set
            {
                Amount = value;
            }
        }
        public string AAmounttype
        {
            get { return Amounttype; }
            set
            {
                Amounttype = value;
            }
        }
    }
}
