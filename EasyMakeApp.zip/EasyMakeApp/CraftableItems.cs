﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyMakeApp
{
    class CraftableItems
    {
        public string CraftableItemName;
        public float CraftableItemAmount;
        public string CraftableItemAmountType;
        
        public CraftableItems(string craftableitemname,float craftableitemamount,string craftableitemamounttype)
        {
            CraftableItemName = craftableitemname;
            CraftableItemAmount = craftableitemamount;
            CraftableItemAmountType = craftableitemamounttype;


        }


    }
}
