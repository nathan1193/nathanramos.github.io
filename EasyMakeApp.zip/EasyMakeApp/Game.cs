﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyMakeApp
{
    class Game
    {
        Player player = new Player();//instantiate PLAYER class
        public Game()
        {
            Console.Title = "Easy Make App 1.0";
            player = new Player();
            while (true)
            {
                Menu();
            }
        }
        public void Menu()
        {
            Console.WriteLine("What would you like to do? \n 1).View inventory \n 2).Make \n 3).View Craftable items");
            string Choice;
            Choice = Console.ReadLine();
            Console.Clear();

            switch (Choice)
            {
                case "1":
                    player.ShowInventory();
                    break;
                case "2":
                    player.Make();
                    break;
                case "3":
                    player.ListCraftableItems();
                    break;
                default:
                    break;
            }
        }

 
    }
}
