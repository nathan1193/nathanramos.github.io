﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyMakeApp
{
    class Player
    {
        List<Item> Inventory = new List<Item>();
        List<CraftableItems> CraftList = new List<CraftableItems>();
        public Player()
        {
            Inventory.Add(new Item("White Flour", 4, "cup(s)"));
            Inventory.Add(new Item("Water", 4, "cup(s)"));
            Inventory.Add(new Item("Salt", 1, "cup(s)"));
            Inventory.Add(new Item("Newspaper Strips", 1, "set(s)"));
            Inventory.Add(new Item("Blue Food Dye", 1, "bottle(s)"));
            Inventory.Add(new Item("Red Food Dye", 1, "bottle(s)"));
            Inventory.Add(new Item("Yellow Food Dye", 1, "bottle(s)"));

            CraftList.Add(new CraftableItems("Orange Food Dye", 0, "bottle(s)"));
            CraftList.Add(new CraftableItems("Green Food Dye", 0, "bottle(s)"));
            CraftList.Add(new CraftableItems("Colored Play-Dough", 0, "Stock(s)"));
            CraftList.Add(new CraftableItems("Paper-Mache", 0, "Sheet(s)"));
            CraftList.Add(new CraftableItems("Plain Play-Dough", 0, "Stock(s)"));
            CraftList.Add(new CraftableItems("Tortilla", 0, "Stocks(s)"));

        }
        public void ListInventoryItems()
        {
            foreach(Item i in Inventory)
            {
                Console.WriteLine($"{i.AAmount} {i.AAmounttype} {i.Name}");
            }
        }
        public void ShowInventory()
        {
            ListInventoryItems();
        }
        public void ListCraftableItems()
        {
            ShowCraftedItems();
        }
        public void ShowCraftedItems()
        {
            foreach(CraftableItems i in CraftList)
            {
                Console.WriteLine($"{i.CraftableItemAmount} {i.CraftableItemAmountType} {i.CraftableItemName}");
            }
        }
        public void Make()
        {
            string Choice;
            Console.WriteLine("What would you like to make? \n 1) Green dye \n 2) Orange dye \n 3) Colored Play-Dough" +
                "\n 4) Paper-Mache \n 5) Plain Play-Doudh \n 6) Tortilla \n------------------------------");
            ListInventoryItems();
            Choice = Console.ReadLine();
            Console.Clear();
            switch (Choice)
            {
                case "1":
                    //make paramter to check if amount is at 0 or not. might need to add a return on it just in search inventory method
                    MakeGreenDye();
                    break;
                case "2":
                    MakeOrangeDye();
                    break;
                case "3":
                    MakeColoredPlayDough();
                    break;
                case "4":
                    MakePaperMache();
                    break;
                case "5":
                    MakePlainPlayDough();
                    break;
                case "6":
                    MakeTortilla();
                    break;
            }
        }
        public bool SearchInventory(string name)
        {
            for (int i = 0; i < Inventory.Count; i++)
            {
                if (name == Inventory[i].Name)
                {
                    return true;
                }

            }
            Console.WriteLine("This item doesn't exist.");
            return false;
        }
        public bool SearchCrafted(string craftedableitemname)
        {
            for (int i = 0; i < CraftList.Count; i++)
            {
                if (craftedableitemname == CraftList[i].CraftableItemName)
                {
                    return true;
                }

            }
            Console.WriteLine("This item doesn't exist.");
            return false;
        }
        /*public bool AmountChecker(float amount, float craftableitemamount)
        {
            for (int i = 0; i < CraftList.Count && i < Inventory.Count; i++)
            {
                if (amount < 0 && craftableitemamount < 0)
                {
                    return true;
                }
            }
            Console.WriteLine("You don't have enough items to do that");
            Console.ReadKey();
            return false;
        }*/
        private void MakeOrangeDye()
        {
            if (SearchInventory("Red Food Dye") && SearchInventory("Yellow Food Dye") /*&& AmountChecker(0,0)*/)
            {
                Inventory[5].AAmount = Inventory[5].AAmount - 1;
                Inventory[6].AAmount = Inventory[6].AAmount - 1;
                CraftList[0].CraftableItemAmount = CraftList[0].CraftableItemAmount + 2;
                Console.WriteLine("You now have " + CraftList[0].CraftableItemAmount + " " + CraftList[0].CraftableItemName);
                Console.ReadKey();
                Console.Clear();
            }
        }
        private void MakeGreenDye()
        {
            if (SearchInventory("Blue Food Dye") && SearchInventory("Yellow Food Dye"))
            {
                Inventory[4].AAmount = Inventory[4].AAmount - 1;
                Inventory[6].AAmount = Inventory[6].AAmount - 1;
                CraftList[1].CraftableItemAmount = CraftList[1].CraftableItemAmount + 2;
                Console.WriteLine("You now have " + CraftList[1].CraftableItemAmount + " " + CraftList[1].CraftableItemName);
                Console.ReadKey();
                Console.Clear();
            }
        }
        private void MakePlainPlayDough()
        {
            if (SearchInventory("White Flour") && SearchInventory("Water") && SearchInventory("Salt"))
            {
                Inventory[0].AAmount = Inventory[0].AAmount - 1;//flour
                Inventory[2].AAmount = Inventory[2].AAmount - (1 / 4);//salt
                Inventory[1].AAmount = Inventory[1].AAmount - (1 / 2);//water
                CraftList[4].CraftableItemAmount = CraftList[4].CraftableItemAmount + 1;
                Console.WriteLine("You now have " + CraftList[4].CraftableItemAmount + " " + CraftList[4].CraftableItemName);
                Console.ReadKey();
                Console.Clear();
            }
        }
        private void MakeColoredPlayDough()
        {
            if (SearchInventory("Blue Food Dye") || SearchInventory("Yellow Food Dye") || SearchInventory("Red Food Dye") || SearchCrafted("Orange Food Dye")
                || SearchCrafted("Green Food Dye"))
            {
                Inventory[4].AAmount = Inventory[4].AAmount - 1;
                Inventory[6].AAmount = Inventory[6].AAmount - 1;
                Inventory[5].AAmount = Inventory[5].AAmount - 1;
                CraftList[0].CraftableItemAmount = CraftList[0].CraftableItemAmount - 1;
                CraftList[1].CraftableItemAmount = CraftList[1].CraftableItemAmount - 1;
                CraftList[2].CraftableItemAmount = CraftList[2].CraftableItemAmount + 1;
                Console.WriteLine("You now have " + CraftList[2].CraftableItemAmount + " " + CraftList[2].CraftableItemName);
                Console.ReadKey();
                Console.Clear();
            }
        }
        private void MakeTortilla()
        {

        }
        private void MakePaperMache()
        {

        }

        /*public float GetInventoryAmount(string name)
         {
         }
         public bool ChangeInventoryAmount(string name, float amount)
         {
         }*/

    }
}
