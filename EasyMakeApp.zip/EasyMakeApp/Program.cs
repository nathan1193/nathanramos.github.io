﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Calvin Oh helped with search inventory function
//need help with not allowing user to create stuff with 0 items
//need help with makecoloredplaydough not take up ALL the dyes

namespace EasyMakeApp
{
    class Program
    {
        static void Main()
        {
            //console is a class? what do u mean?

            Game game = new Game();


        }
    }
}
