﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_Dresser
{
    class Clothes
    {
        private string Nameofclothes;
        private string Descofclothes;

        public Clothes(string nameofclothes, string descofclothes)//parameters for array
        {
            ANameofclothes = nameofclothes;//
            ADescofclothes = descofclothes;// having the get/setter = the private strings, it ensures that whoever wants to modify
            //the values of the strings in the array can't change it to whatever they want
        }
        public Clothes()//constructor
        {

        }

        public string ANameofclothes //a get/setter method/function which ONLY let's me or other users change the name of
            //the PRIVATE STRING NAMEOFCLOTHES TO CERTAIN WORDS. IT ALSO LET'S PRIVATE VARIABLES BE USED/CALLED FROM OTHER CLASSES
            //WHERE THE OTHER CLASSES CAN MODIFY THE VARIABLE VALUES, BUT ONLY MODIFY THE VAIRABLE VALUES TO WHAT THE SETTER IN HERE HAS
            //it also is a "substitute" for the private string Nameofclothes
        {
            
            get { return Nameofclothes; } //allows me to get/use the private string NAMEOFCLOTHES

            set {
                if (value == "Santa hat" || value =="Beanie hat" || value == "Knitted Bobble hat"
                    || value == "Knitted Mittens" || value == "Fuzzy Mittens" || value == "Oven Mittens")
                    //if whoever is modifying NAMEOFCLOTHES value is equal to these 3 string, Nameofclothes will be able to be used
                {
                    Nameofclothes = value;
                }
                else
                {
                    Nameofclothes = "STOP CHEATING";
                }
            }
        }
        public string ADescofclothes
        {
            get { return Descofclothes; }//allows me to get/use the private string of DESCOFCLOTHES
            set {
                if(value == "  A great hat for the winter holidays." || value == " A snazzy look for your dog." ||value == " A soft look for your favorite friend."
                    || value == " Soft mittens with doggy patterns printed on it" || value ==" Fuzzy mittens that glow when the dog is happy" ||
                    value ==" Only for doggos that like to bake")
                {
                    Descofclothes = value;
                }
                else
                {
                    Descofclothes = "STOP CHEATING BRO";
                }
            }
        }

        
    }
}
