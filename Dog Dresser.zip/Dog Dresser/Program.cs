﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_Dresser
{
    class Program
    {
       
        static void Main(string[] args)
        {
            DressGame dressgame = new DressGame();//instantiates the class DRESSGAME

            dressgame.Game(); //calls on the GAME method in CLASS DRESS GAME

        }
    }
}
