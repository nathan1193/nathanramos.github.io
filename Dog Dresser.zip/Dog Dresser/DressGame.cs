﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_Dresser
{
    class DressGame
    {
        Dog dog = new Dog();
        public void Game()
        {
            Console.Title = "Dres your Dog";
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine(@"
██████╗░░█████╗░░██████╗░  ██████╗░██████╗░███████╗░██████╗░██████╗███████╗██████╗░
██╔══██╗██╔══██╗██╔════╝░  ██╔══██╗██╔══██╗██╔════╝██╔════╝██╔════╝██╔════╝██╔══██╗
██║░░██║██║░░██║██║░░██╗░  ██║░░██║██████╔╝█████╗░░╚█████╗░╚█████╗░█████╗░░██████╔╝
██║░░██║██║░░██║██║░░╚██╗  ██║░░██║██╔══██╗██╔══╝░░░╚═══██╗░╚═══██╗██╔══╝░░██╔══██╗
██████╔╝╚█████╔╝╚██████╔╝  ██████╔╝██║░░██║███████╗██████╔╝██████╔╝███████╗██║░░██║
╚═════╝░░╚════╝░░╚═════╝░  ╚═════╝░╚═╝░░╚═╝╚══════╝╚═════╝░╚═════╝░╚══════╝╚═╝░░╚═╝");
            Console.ResetColor();
            Console.WriteLine("Press enter to starting giving your dog sum luv!");
            Console.ReadKey();
            Console.Clear();
            dog.Dressdog();
            Console.ReadKey();

        }

       
    }
}
