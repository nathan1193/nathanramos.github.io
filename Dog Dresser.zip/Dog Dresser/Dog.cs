﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dog_Dresser
{

    class Dog
    {
        Clothes[] hats = new Clothes[3];
        Clothes[] mittens = new Clothes[3];
        Clothes[] shirts = new Clothes[3];
        string name;
        string dogname;
        string input;
        string input1;
        public void Dressdog()
        {
            input = "";
            input = "";
            Clothes clothes = new Clothes(); //instantiates CLOTHES class
            
            hats[0] = new Clothes("Santa hat", "  A great hat for the winter holidays.");
            hats[1] = new Clothes("Beanie hat"," A snazzy look for your dog.");
            hats[2] = new Clothes("Knitted Bobble hat", " A soft look for your favorite friend.");
            mittens[0] = new Clothes("Knitted Mittens", " Soft mittens with doggy patterns printed on it");
            mittens[1] = new Clothes("Fuzzy Mittens", " Fuzzy mittens that glow when the dog is happy");
            mittens[2] = new Clothes("Oven Mittens", " Only for doggos that like to bake");
            shirts[0] = new Clothes("", "");//could add more stuff in the future
            shirts[1] = new Clothes("", "");
            shirts[2] = new Clothes("", "");

            Console.WriteLine("Hello, what is your name?");
            name = Console.ReadLine();
            Console.WriteLine("Oh, hello " + name + ". What's your dog's name?");
            dogname = Console.ReadLine();
            Console.WriteLine("Ok, what would you like to dress your dog " + dogname + " with? \nPlease select a hat " +
                "by typing out its full name EXACTLY. ie: Santa hat");
            Allitems();
            Console.WriteLine("Please select a pair of mittens by typing in its full name EXACTLY. ie: Fuzzy Mittens");
            Allitems1();
            Console.Clear();
            Finalizedress();
        }
        public void Allitems()
        {
            int i;
            for (i = 0; i < hats.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(hats[i].ANameofclothes + hats[i].ADescofclothes);
                Console.ResetColor();
                //Console.WriteLine("------------------------------------------------------------------------");
                //Console.WriteLine("CHOOSE 1 pair of MITTEN");
            }
            input = Console.ReadLine();
            if (input == hats[0].ANameofclothes || input == hats[1].ANameofclothes || input == hats[2].ANameofclothes)
            {
                Console.WriteLine("Great choice, I love " + input);
            }
            else
            {
                Console.WriteLine("That's not an item.");
                Allitems();
            }
        }
        public void Allitems1()
        {
            int i;
            for (i = 0; i < mittens.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(mittens[i].ANameofclothes + mittens[i].ADescofclothes);
                Console.ResetColor();

            }
            input1 = Console.ReadLine();
            if (input1 == mittens[0].ANameofclothes || input1 == mittens[1].ANameofclothes || input1 == mittens[2].ANameofclothes)
            {
                Console.WriteLine("Great choice, I love " + input1);
            }
            else
            {
                Console.WriteLine("That's not an item.");
                Allitems1();
            }
        }
        public void Finalizedress()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine(@"
██████╗░░█████╗░░██████╗░  ██████╗░██████╗░███████╗░██████╗░██████╗███████╗██████╗░
██╔══██╗██╔══██╗██╔════╝░  ██╔══██╗██╔══██╗██╔════╝██╔════╝██╔════╝██╔════╝██╔══██╗
██║░░██║██║░░██║██║░░██╗░  ██║░░██║██████╔╝█████╗░░╚█████╗░╚█████╗░█████╗░░██████╔╝
██║░░██║██║░░██║██║░░╚██╗  ██║░░██║██╔══██╗██╔══╝░░░╚═══██╗░╚═══██╗██╔══╝░░██╔══██╗
██████╔╝╚█████╔╝╚██████╔╝  ██████╔╝██║░░██║███████╗██████╔╝██████╔╝███████╗██║░░██║
╚═════╝░░╚════╝░░╚═════╝░  ╚═════╝░╚═╝░░╚═╝╚══════╝╚═════╝░╚═════╝░╚══════╝╚═╝░░╚═╝");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Congrats, you successfully dressed your dog!");
            Console.ResetColor();
            Console.WriteLine("You dressed " + dogname + " with a " + input + " and a pair of " + input1);
        }
    }
}
