﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_example
{
    class Snowcone
    {
        string Name;
        string Desc;

        public Snowcone[] heroname = new Snowcone[3];// array for hero names

        public void Pickhero()
        {
            //array for Snowcone
            heroname[0] = new Snowcone("Fantoma", " cone graphic is Fantomah's face morphing. 152 sold");
            heroname[1] = new Snowcone("Tigra", " cone graphic is Tigra summoning the Balkatar. 296 sold");
            heroname[2] = new Snowcone("Moon Knight",  "cone graphic is Moon Knight before a statue of khonshu. 145 sold");

            Console.WriteLine("This month's  sales \n -------------------------------------- \n");
            int i;

            for (i = 0; i < heroname.Length; i++)
            {
                Console.WriteLine(heroname[i].Name + heroname[i].Desc);

            }

            Console.ReadKey();

        }

        public Snowcone (string name, string desc)//constructor for Snowcone array
        {
            Name = name;
            Desc = desc;

        }
        public Snowcone()
        {

        }
    }
}
