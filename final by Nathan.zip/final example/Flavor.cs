﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_example
{
    class Flavor
    {
        string Name;
        string Ingredient;
        string Color;

        
        public  Flavor[] Flavorname = new Flavor [5];//initializing array for flavorname


        public void  PickFlavor()
        {
            //array for flavors, also has the string parameters name, color and ingredient
            Flavorname[0] = new Flavor("Flavor: Jungle Defence.", " Color: Green.", " Flavor : green apple, pineapple, and mango");
            Flavorname[1] = new Flavor("Flavor: Death Pall.", " Color : Light Blue.", " Flavor : blueberry and banana");
            Flavorname[2] = new Flavor("Flavor: Retribution.", " Color : Black."," Flavor : blackberry");
            Flavorname[3] = new Flavor("Flavor: Ferocity.",  "Color : Orange.", " Flavor : lemon, orange and lime");
            Flavorname[4] = new Flavor("Flavor: Vengeance.", " Color : Light Green."," Flavor : kiwi, mango and mint");

            int i;

            for (i = 0; i < Flavorname.Length; i++) //increments through all elements in array
            {

                Console.WriteLine(Flavorname[i].Name + Flavorname[i].Color + Flavorname[i].Ingredient);//prints out the array elements for FLAVORNAME

            }
            Console.WriteLine("Press enter to check this month's sales. \n");
            Console.ReadKey();
        }
        public Flavor(string name,string color,string ingredient)//constructor for array for flavors, constructor has name, color, and ingredient
        {
            Name = name;
            Ingredient = ingredient;
            Color = color;

        }

        public Flavor()//argument that corresponds to the parameters of the Flavor array
        {
           
        }
    }
}
