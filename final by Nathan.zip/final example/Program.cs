﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_example
{
    class Program
    {
        static void Main(string[] args)
        {
            Vendor vendor = new Vendor();//instantiates the class Vendor, to allow me to call on its method
            vendor.Showmonthresults();
        }
    }
}
