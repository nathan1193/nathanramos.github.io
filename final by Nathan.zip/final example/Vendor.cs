﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_example
{
    class Vendor
    {
        public string name = "Super Sweets";
        public string location = "916. S Wabash Chicago";
        public static Flavor flavor = new Flavor();//instantiates the class FLAVOR in this class as the word flavor
        public static Snowcone hero = new Snowcone(); //instantiating the class SNOWCONE

        public void Showmonthresults()
        {
            Console.Title = "Super Sweets by Nathan Ramos";
            Console.WriteLine(" Super Sweet Sales of Super Hero Snow Cones");
            
            Console.WriteLine("Welcome! This is " + name + " " + location + "! Check out our wonderful flavors! \n ---------------------------------------------------------");
            flavor.PickFlavor();
            hero.Pickhero();
            //will be the method that encompasses class Flavor and class Snowcone method



            Console.ReadKey();

        }
    }
}
