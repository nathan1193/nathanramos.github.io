﻿using static System.Console;


namespace Deem_encoder
{
    class Base
    {
        public static Encode encode1 = new Encode();
        public static Decode decode1 = new Decode();
        public Shift shift1 = new Shift();
        public void myBase()
        {


            WriteLine("Would you like to encode or decode or shift caesar? (E) (D) (S)");

            string useranswer = ReadLine();

            if (useranswer == "E")
            {

                encode1.myEncode();

            }

            else if (useranswer == "D")
            {


                decode1.myDecode();


            }
            else if (useranswer == "S")
            {
                string s = shift1.getWordFromUser();
                int x = shift1.getNumberToShift();
                WriteLine("Shifted: " + shift1.shiftLetters(s, x));
                ReadKey();
            }
        }
    }
}
