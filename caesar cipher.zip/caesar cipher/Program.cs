﻿//Nathan rmaos
//used C# forums/sites as help to figure out how to approach this problem, because I literally had no idea how to implement the optional "Shifting" part of the code. I also felt like the classes DECODE and ENCODE already did the shift for me already... 
//Angelo Casagrande de Mello helped tutor me on the Shifting caesar logic, and helped teach converting data

//why isn't class BASE able to call on class SHIFT, when SHIFT's method does have arguments that respond to "myString"(SOLVED)

using static System.Console;

namespace Deem_encoder
{
    class Program
    {
        public static Base Base1 = new Base();
        static void Main()
        {


            Base1.myBase();

        }
    }
}