﻿using System;
using static System.Console;


namespace Deem_encoder
{
    public class Shift
    {
        char[] alphabet = {'a' , 'b' , 'c' , 'd' , 'e' , 'f' , 'g' , 'h' , 'i' , 'j' , 'k' , 'l' , 'm' , 'n' , 'o' , 'p' , 'q' , 'r' , 's' , 't' , 'u' , 'v' , 'w' , 'x', 'y', 'z' };


        public string getWordFromUser()
        {
            WriteLine("Type a word to be shifted");
            string s = Console.ReadLine();
            return s;
        }

        public int getNumberToShift()
        {
            WriteLine("Type number of how much you would like to shift");
            int x = Convert.ToInt32(Console.ReadLine());
            return x;
        }


        public string shiftLetters(string mystring, int numberToShift)
        {

            char[] convertedString = convertStringtoArrayOfChar(mystring);

            for (int i = 0; i < convertedString.Length; i++)
            {
                for (int j = 0; j < alphabet.Length; j++)
                {
                    if (convertedString[i] == alphabet[j]) // U
                    {
                        if ((j + numberToShift) > alphabet.Length) // j = 20 + 10 = 30    30 > 25 
                        {
                            int x = j + numberToShift - alphabet.Length + 1;  // x = 20 + 10 - 25 = 5
                            convertedString[i] = alphabet[x]; //F;
                        }
                        else
                        {
                            j = j + numberToShift + 1;
                            convertedString[i] = alphabet[j];
                        }
                    }
                }
            }

            return convertArrayOfCharToString(convertedString);
        }

        string convertArrayOfCharToString(char[] convertedString)
        {
            string mystring = new string(convertedString);

            return mystring;
        }

        char[] convertStringtoArrayOfChar(string mystring)
        {
            char[] convertedString = mystring.ToCharArray();

            return convertedString;
        }
    }
}
