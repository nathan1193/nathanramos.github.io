﻿using static System.Console;


namespace Deem_encoder
{
    class Decode
    {


        public void myDecode()
        {

            string CorrectAlphabet = "abcdefghijklmnopqrstuvwxyz ";
            string CypherAlphebet = "ghijklmnopqrstuvwxyzabcdef ";

            WriteLine("What would you like to Decode? ");

            string userPhrase = ReadLine();

            System.Text.StringBuilder sb = new System.Text.StringBuilder(userPhrase);
            System.Text.StringBuilder sb2 = new System.Text.StringBuilder(CorrectAlphabet);
            System.Text.StringBuilder sb3 = new System.Text.StringBuilder(CypherAlphebet);



            int temp = 0;

            for (int i = 0; i < sb.Length; ++i)
            {

                for (int k = 0; k < sb3.Length; ++k)
                {

                    if (sb[i] == sb3[k])
                        temp = k;

                }

                sb[i] = sb2[temp];


            }

            userPhrase = sb.ToString();
            WriteLine(userPhrase);
            ReadKey();

        }


    }
}
