﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mcdonalds_menu
{
    class Program
    {
        static void Main()
        {
            Restaurant restaurant = new Restaurant();

            restaurant.Mcdonald();

        }
    }
}
