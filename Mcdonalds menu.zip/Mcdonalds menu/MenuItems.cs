﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mcdonalds_menu
{
    class MenuItems
    {
        public string Name;
        public string Desc;
        public string Itemselection;
        private double Price; 


        //paramters/constructor for MENUITEMS array
        public MenuItems (string itemselection,string name, string desc,double price)
        {

            Name = name;
            Desc = desc;
            Itemselection = itemselection;
            Aprice = price;

        }
        
        
        public double Aprice
        {
            get { return Price; }
            set
            {
                if (value == 1.00 || value == 2.00 || value == 3.00)
                {
                    Price = value;
                }
                else Console.WriteLine("That's not a valid price.");
            }
        }

    }
}
