﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mcdonalds_menu
{
    class Order
    {
        public string Userinput;
        public double Tax;
        public double Usermoney;
        public double ResultPrice;
        public double ResultLeftover;
        //instantiated array of MENUITEMS
        public void Pickitem()
        {
            //instantiation of the constructed array in MENUITEMS
            MenuItems[] items = new MenuItems[3];
            items[0] = new MenuItems("1", ").Burger.", " A standard Mcdonald's burger. $", 1.00);
            items[1] = new MenuItems("2", ").Fries.", " A standard Mcdonald's fries. $", 2.00);
            items[2] = new MenuItems("3", ").Smoothie.", " A standard Mcdonald's smoothie. $", 3.00);

            int i;
            for (i = 0; i < items.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine(items[i].Itemselection + items[i].Name + items[i].Desc + items[i].Aprice);
                Console.ResetColor();
            }

            Buyitem();

        }

        public void Buyitem()
        {
            int i;
            Userinput = "";
            Usermoney = 20.00;
            Tax = .2;
            MenuItems[] items = new MenuItems[3];
            items[0] = new MenuItems("1", "Burger", " A standard Mcdonald's burger. $", 1.00);
            items[1] = new MenuItems("2", "Fries", " A standard Mcdonald's fries. $", 2.00);
            items[2] = new MenuItems("3", "Smoothie", " A standard Mcdonald's smoothie. $", 3.00);
            Console.WriteLine("\nYou have $" + Usermoney + " \nPlease Select an item by its number to purchase");
            Userinput = Console.ReadLine();

            if (Userinput == items[0].Itemselection)
            {
                Console.Clear();
                ResultPrice = (items[0].Aprice * Tax) + items[0].Aprice;
                Console.WriteLine("Your total is $" + ResultPrice + " included with tax. Would you like to purchase the " + items[0].Name + "?" +
                    "\n 1 = yes, 2 = no.");
                Userinput = Console.ReadLine();
                if (Userinput == "1")
                {
                    ResultLeftover = (Usermoney - ResultPrice);
                    Console.WriteLine("*You recieved the " + items[0].Name + "*\n You now have $" + ResultLeftover + ".");

                }
                else
                {
                    Console.Clear();
                    Pickitem();
                }
            }
            if (Userinput == items[1].Itemselection)
            {
                Console.Clear();
                ResultPrice = (items[1].Aprice * Tax) + items[1].Aprice;
                Console.WriteLine("Your total is $" + ResultPrice + " included with tax. Would you like to purchase the " + items[1].Name + "?" +
                    "\n 1 = yes, 2 = no.");
                Userinput = Console.ReadLine();
                if (Userinput == "1")
                {
                    ResultLeftover = (Usermoney - ResultPrice);
                    Console.WriteLine("*You recieved the " + items[1].Name + "*\n You now have $" + ResultLeftover + ".");

                }
                else
                {
                    Console.Clear();
                    Pickitem();
                }
            }
            if (Userinput == items[2].Itemselection)
            {
                Console.Clear();
                ResultPrice = (items[2].Aprice * Tax) + items[2].Aprice;
                Console.WriteLine("Your total is $" + ResultPrice + " included with tax. Would you like to purchase the " + items[2].Name + "?" +
                    "\n 1 = yes, 2 = no.");
                Userinput = Console.ReadLine();
                if (Userinput == "1")
                {
                    ResultLeftover = (Usermoney - ResultPrice);
                    Console.WriteLine("*You recieved the " + items[2].Name + "*\n You now have $" + ResultLeftover + ".");

                }
                else
                {
                    Console.Clear();
                    Pickitem();
                }
            }
        }
    }
}
