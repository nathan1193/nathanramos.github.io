﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mcdonalds_menu
{
    class Restaurant
    {
        public void Mcdonald()
        {
            Order order = new Order();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Welcome to Mcdonald's drive thru\n");
            Console.ResetColor();
            order.Pickitem();
            Console.WriteLine("Goodbye");
            Console.ReadKey();
        }

    }
}
