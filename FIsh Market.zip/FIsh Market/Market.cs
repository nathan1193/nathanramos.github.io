﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIsh_Market
{
    class Market
    {
        string name;
        Cashier cashier = new Cashier();
        public void EnterMarket()
        {
            name = "Boston Fish Market";
            Console.WriteLine("Welcome to " + name + " ! \n");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Please buy something from the menu by entering its number \n ----------------------------------------------");
            Console.ResetColor();
            cashier.PickFish();
           
            Console.ReadKey();
        }

    }
}
