﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIsh_Market
{
    class Fish
    {
        //private strings/private double
        public string Name;
        public string Desc;
        public string SelectionNumber;
        private double Price;


        //parameters= array must have a string name, desc and double price
        public Fish(string selectionnumber,string name, string desc, double price)
        {
            SelectionNumber = selectionnumber;
            Name = name;
            Desc = desc;
            APrice = price;
        }
        //constructor= allows me to call this class's array



        //get set = only allows the price to equal 1.00 or 2.00
        public double APrice
        {
            get { return Price; } //allows the PRIVATE double PRICE to be accessed through the PUBLIC double APRICE
            set
            {
                if (value == 8.00 || value == 7.75 || value == 6.99)
                {
                    Price = value;
                }
                else
                {
                    Console.WriteLine("Not a valid price");
                }
            }
        }


    }
}
