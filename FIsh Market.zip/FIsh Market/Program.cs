﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIsh_Market
{
    class Program
    {
        
       
         static void Main()
        {
            Market market = new Market();
            market.EnterMarket();
        }
    }
}
