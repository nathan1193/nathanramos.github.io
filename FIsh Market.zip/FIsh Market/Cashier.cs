﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIsh_Market
{
    class Cashier
    {
        public double Tax;
        public double Result;
        public double ResultLeftover;
        public int i;
        public string UserSelectFish;
        public string Userinput;
        public double Usermoney;

        public void PickFish()
        {

            Userinput = "";
            Fish[] allfish = new Fish[3];//instantiate the array that's made in the FISH class
            allfish[0] = new Fish ("1"," : Trout"," This is a trout $", 8.00);
            allfish[1] = new Fish("2"," : Mackeral", " This is a mackeral $", 7.75);
            allfish[2] = new Fish("3"," : Tilapia", " This is a tilapia $", 6.99);

            for (i = 0; i < allfish.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine(allfish[i].SelectionNumber + allfish[i].Name + allfish[i].Desc + allfish[i].APrice);
                Console.ResetColor();
            }
            BuyFish();                
            
        }

        public void BuyFish()
        {

            Usermoney = 10.00;
            Console.WriteLine("You currently have $" + Usermoney);
            UserSelectFish = " ";
            UserSelectFish = Console.ReadLine();
            Fish[] allfish = new Fish[3];//instantiate the array that's made in the FISH class
            allfish[0] = new Fish("1", " : Trout", " This is a trout $", 8.00);
            allfish[1] = new Fish("2", " : Mackeral", " This is a mackeral $", 7.75);
            allfish[2] = new Fish("3", " : Tilapia", " This is a tilapia $", 6.99);


            Tax = .2;
            if (UserSelectFish == allfish[0].SelectionNumber)
            {
                Result = (Tax * allfish[0].APrice) + allfish[0].APrice;
                ResultLeftover = (Usermoney - Result);
                Console.WriteLine("Your payment will be $" + Result);
                Console.WriteLine("You now have $" + ResultLeftover +" left.");
            }
            if (UserSelectFish == allfish[1].SelectionNumber)
            {
                Result = (Tax * allfish[1].APrice) + allfish[1].APrice;
                ResultLeftover = (Usermoney - Result);
                Console.WriteLine("Your payment will be $" + Result);
                Console.WriteLine("You now have $" + ResultLeftover + " left.");
            }
            if (UserSelectFish == allfish[2].SelectionNumber)
            {
                Result = (Tax * allfish[2].APrice) + allfish[2].APrice;
                ResultLeftover = (Usermoney - Result);
                Console.WriteLine("Your payment will be $" + Result);
                Console.WriteLine("You now have $" + ResultLeftover + " left.");
            }
        }
    }
}
