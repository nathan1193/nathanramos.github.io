﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Madlib_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //empty string variables waiting to be replaced by what the user inputs
        string smasher;
        string shrimp;
        string hands;
        string fastest;
        string bullet;
        string result;
        string thaichi;
        string fifteenthousand;
        string powerful;
        string shit;
        string fast;
        string bubbles;
        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            //whatever the user inputs for each string, they will be replaced inside
            //the "___ REPLACEMENT" textboxes
            smasher = (SmasherReplacement.Text); 
            shrimp = (ShrimpReplacement.Text);
            hands = (HandsReplacement.Text);
            fastest = (FastestReplacement.Text);
            bullet = (BulletReplacement.Text);
            thaichi = (ThaichiReplacement.Text);
            fifteenthousand = (FifteenthousandReplacement.Text);
            powerful = (PowerfulReplacement.Text);
            shit = (ShitReplacement.Text);
            fast = (FastestReplacement.Text);
            bubbles = (BubblesReplacement.Text);



            result = ("Alternatively the " + smasher + " mantis " + shrimp + " have little," +
                " Edward bowling ball " + hands + ", that they used to punch the crap out of basically," +
                " everything. They have the " + fastest + " punch in the world, with the same " +
                "acceleration as a 22 caliber " + bullet + ". To a mantis " + shrimp + " kung fu looks like "
                + thaichi + ". The mantis " + shrimp +" can deliver a blow with " + fifteenthousand + " Newtons of force, " +
                "which tells you what a sissy punch Newton must have had. That punch is so " + powerful + " " +
                "that the universe can't handle it water moves out of the way so " + fast +  " that little vacuums are formed, called " +
                "caviation " + bubbles + ". These bubbles collapse immediately, and the force of that collapse creates " +
                "a second shockwave and even generates light and heat. That's some mortal kombat finishing move " +
                shit + " right there.");
            Result.Text = result;
        }
    }
}
